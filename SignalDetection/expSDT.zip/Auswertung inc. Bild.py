
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
import pandas as pd
import matplotlib.pyplot as plt
import os 
import numpy as np
import scipy
import math
from PIL import Image
import psignifit as ps



######### Panda ##########
### getting path
_thisDir = os.path.dirname(os.path.abspath(__file__))

# Erstellt eine Liste mit den Namen von allen CSV Datein, die sich im 
# im gleichen Pfad (unterordner data) befindet
def createListOfAllCSVFilesInDic ():

    #### Automatically find all dataframes and put the name in FileNames
    
    # List to hold file names
    FileNames = []
    
    # Your path will be different, please modify the path below.
    os.chdir(_thisDir + os.sep + r'data')
    
    # Find any file that ends with ".xlsx"
    for files in os.listdir("."):
        if files.endswith(".csv"):
            FileNames.append(files)
            
    return FileNames



# get all Files in Given Dictonary
def GetFile(file_name):

    # Path to excel file
    # Your path will be different, please modify the path below.
    location = _thisDir + os.sep + r'data/' + file_name
    # Parse the excel file
    # 0 = first sheet
    df = pd.read_csv(location)
    
    # Tag record to file name
    df['File'] = file_name
    
    # Make the "File" column the index of the df
    return df.set_index(['File'])


###############

    #Gibt gefiltertes subdatenset für bestimmte Versuchsperson heraus
def create_subdataset_for_participant (name):
    
    participant_data = subData.loc[subData['participant'] == name]
    participant_data = participant_data.loc[participant_data['session'] == 2 ]
    
    return participant_data

    #Gibt gefiltertes subdatenset für bestimmte Versuchsperson im 2IFC-Task heraus
def create_subdataset_for_participant2IFC (name):
    
    participant_data2IFC = subData2IFC.loc[subData2IFC['participant'] == name]
    participant_data2IFC = participant_data2IFC.loc[participant_data2IFC['session'] == 2 ]
    
    return participant_data2IFC

    #erstellt gefiltertes subdatenset mit allen False Alarms sowie wrong answer
def create_subdataset_for_FalseAlarms ():

    participant_dataFalseAlarm = subData.loc[subData['response'] == 'False Alarm']
    participant_dataNotCorrect = subData2IFC.loc[subData2IFC['response'] == 'wrong answer']
    result = participant_dataFalseAlarm.append(participant_dataNotCorrect, ignore_index=True)
    
    return result
    
    
    # calculate the propability of a correct answer for each signal Intesnity
def evaluation2IFC (dataPlot):
    # listet alle verschiedenen Signalstärken in den übergebenen Daten auf
    list_of_intensitys = dataPlot['signal_intensity'].value_counts().index.tolist()
    
    correct_fit = []
    n_total_fit = []
    
    #Schleife die jede Signalstärke in Daten behandelt
    for x in list_of_intensitys:
        
        #erstellt subdataset für alle daten mit Signalstärke x
        dataframe_signalintensity = dataPlot[dataPlot['signal_intensity'] == x]
        
        dataCorrect = dataframe_signalintensity[dataframe_signalintensity['response']=='correct answer']
        
        dataWrong = dataframe_signalintensity[dataframe_signalintensity['response']=='wrong answer']
        
        correct_fit.append(dataCorrect.shape[0])
        n_total_fit.append(dataWrong.shape[0] + dataCorrect.shape[0])


    # Array um mit Psysignifit zu plotten
    data2IFC = np.empty([len(list_of_intensitys),3], dtype=float)
    
    intensitys = np.array(list_of_intensitys)
    
    correct_psyfit = np.array(correct_fit)
    n_total_psyfit = np.array(n_total_fit)
    
    o=0
    
    #Für jede Signalstärke Anzahl Korrekt und Anzahl Ges zusammen speichern
    for k in intensitys:
        
        #Signalstärke
        data2IFC[o][0] = intensitys[o]
        #Dazugehörige Anzahl korrekt
        data2IFC[o][1] = correct_psyfit[o]
        #Von N insgesammt
        data2IFC[o][2] = n_total_psyfit[o]

        o = o+1
    return (data2IFC)

    #calculate the response time for the YesNoData and twoIFCData
def responsetime(YesNoData, twoIFCData):

    responseTimeYN = YesNoData['time_response'].value_counts().index.tolist()
    responseTime2IFC = twoIFCData['time_response'].value_counts().index.tolist()
    
    time = 0.000
    k = 0
    #addiert alle Antwortzeiten des Yes-No Tasks aufeinander
    for entry in responseTimeYN:
        time = time + responseTimeYN[k]
        k = k+1
    responseTime = time / len(responseTimeYN)
    
    time = 0.000
    k = 0
    #addiert alle Antwortzeiten des 2IFC Tasks aufeinander
    for entry in responseTime2IFC:
        time = time + responseTime2IFC[k]
        k = k+1
    responseTimeTwo = time / len(responseTime2IFC)
    
    print(responseTime)
    print(responseTimeTwo) 

    #mittelt alle False Alarm Bilder
def makePictureOverAll(filteredData):
    #filteredData muss False Alarms vom Yes-No-Task beinhalten
    #sowie alle wrong answers vom 2IFC Task 

    lengthOfData = 0

    # pfad wo sich skript befindet
    script_dir = os.path.dirname(__file__)
    YesNoData = filteredData.loc[filteredData['expName'] == "Yes-No Task"]
    
    # Namen der False Alarm Bilder aus den Yes-No Task
    pictureNames  = YesNoData['stimulus_name_pos1'].value_counts().index.tolist()

    twoIFCData = filteredData.loc[filteredData['expName'] == "2IFC"]

    

    #Wir haben nur wrong answers vom 2IFC Task übergeben, das heißt wir müssen schauen
    #in welchem Intervall kein Signal war.
    #Signal war im ersten Intervall --> also wurde mit wrong answer das zweite Intervall ausgewählt
    twoIFCSecond = twoIFCData.loc[twoIFCData['signal_on_stimuluspos1'] == True]
    #Speichere alle wrong anwer Bilder aus dem zweiten Interval ab (alle ohne Stimulus) 
    pictureNamesSecond = twoIFCSecond['stimulus_name_pos2'].value_counts().index.tolist()
    
    #Signal war im zweiten Intervall --> also wurde bei wrong answer das erste Intervall ausgewählt
    twoIFCFirst = twoIFCData.loc[twoIFCData['signal_on_stimuluspos1'] == False]
    pictureNamesFirst = twoIFCFirst['stimulus_name_pos1'].value_counts().index.tolist()
    
    # Liste mit allen namen von Bildern die ein False Alarm bzw. wrong answer waren
    combinedList = pictureNames + pictureNamesSecond + pictureNamesFirst
    
    #zum überprüfen
#    print(len(pictureNames))
#    print(len(pictureNamesSecond))
#    print(len(pictureNamesFirst))
#    print(len(combinedList))
    
    pictureNamesAr = np.array(combinedList)

#    ###############
    FileNames= []
 
    # Pfad für die folgende Suche
    os.chdir(_thisDir + os.sep + r'data/Fotos')

    # findet jedes File, das mit .jpg endet
    for files in os.listdir("."):

        if files.endswith('.jpg'):

            # letzen 4 zeichen .jpg
            # werden zum Vergleich mit Bildernamen aus Datenframe Abgeschnitten
            fileExpand = files[:-4]
            
            #Die Bildernamen im Datenframe haben zusätzlich noch die vorsilbe stimulus,
            #im Gegensatz zu den abgespeicherten Namen
            #Yes-No Bilder haben ein "_" zwischen vorsilbe stimulus und dem Dateinamen
            filePlusStimulus = "stimulus_"+fileExpand
            #2IFC Daten haben dies nicht
            filePlusStimulustwoIFC = "stimulus"+fileExpand
            
            #Vergleicht Namen der Bilder aus Datenframe mit Namen der 
            #Gesammelten .jpg datein, und Speichert die Namen der .jpg datein ab
            
            
            #ausklammern um nur 2Ifc zu bekommen
            if filePlusStimulus in pictureNamesAr:
#                print ('ja')
                FileNames.append(files)
            ### bis hier
                
            
            #### ausklammern um nur yes/no zu bekommen
            if filePlusStimulustwoIFC in pictureNamesAr:
#                print ('ja')
                FileNames.append(files)
            #### bis hier
            
    #mit wie vielen Bildern gearbeitet wird       
    lengthOfData = len(FileNames)
    counter = 0
    
    #leere Matritzen zum rechnen
    returnRGBMatrix = np.zeros(
        (64,64,3),
        dtype=np.uint8)
    RGBMatrix = np.zeros(
        (64,64,3),
        dtype=np.uint8)
    imgpre = np.zeros(
        (64,64,3),
        dtype=np.uint8)
        
    #Matrix voll mit der Anzahl an Bildern die berücksichtigt werden
    divideRGBMatrix = np.full(
        (64,64,3),lengthOfData)
    
    #Schleife welche jedes Bild auswertet und aufsummiert
    while counter < lengthOfData:
        rel_path = 'data/Fotos/' +FileNames[counter]
        #erstellt Pfad zum Bild
        image_path = os.path.join(script_dir, rel_path)
        # img hält das geladene Bild
        img = Image.open(image_path)
        # holt die Pixelwerte und speichert diese in pixels ab
        pixels = np.asarray(img)
        
        # wird benötigt um mit der Pixelmatrix zu arbeiten
        pixels.setflags(write=1)
        
        #teilet den Pixelwert durch die Gesammtzahl der Bilder
        RGBMatrix = np.divide(pixels,divideRGBMatrix)
        #addiere RGBMatrix auf die returnRGBMatrix
        returnRGBMatrix = RGBMatrix + returnRGBMatrix
        counter = counter + 1
    
    #Umwandlung und Speicherung des Ergebnisbildes
    imgpre = np.round_(returnRGBMatrix, decimals=0)
    print(imgpre)
    b = np.uint8(imgpre)
    img = Image.fromarray(b)
    img.save(_thisDir + os.sep + '/FotoOverall' + ".jpg", "JPEG", quality=100)
    
    #Kontrast erhöhen möglich, bis zu 4 verschiedene Kontraständerungen möglich
    #hier spielerreien möglich wie/ wann eingefärbt wird und wie stark
    grater = np.where(imgpre[:, :, 0] >= 128)
#    grater2 = np.where(imgpre[:, :, 0] > 128)
    smaler = np.where(imgpre[:, :, 0] <= 127)
#    smaler2 = np.where(imgpre[:, :, 0] < 127)
    
    #Speichert für jeden gefundenen Pixelwert seine x und y position ab
    graterX = grater[0]
    graterY = grater [1]
    smalerX = smaler [0]
    smalerY = smaler [1]
#    graterX2 = grater2[0]
#    graterY2 = grater2 [1]
#    smalerX2 = smaler2 [0]
#    smalerY2 = smaler2 [1]
    i = 0
    
    #Pixelwert an position x,y wird genommen und erhöht
    while i < len(graterX):
           imgpre[graterX[i],graterY[i],0] = imgpre[graterX[i],graterY[i],0] + 100
           imgpre[graterX[i],graterY[i],1] = imgpre[graterX[i],graterY[i],1] + 100
           imgpre[graterX[i],graterY[i],2] = imgpre[graterX[i],graterY[i],2] + 100
           i = i+1 
    i = 0 
    #bzw. verringert
    while i < len(smalerX):
           imgpre[smalerX[i],smalerY[i],0] = imgpre[smalerX[i],smalerY[i],0] - 100
           imgpre[smalerX[i],smalerY[i],1] = imgpre[smalerX[i],smalerY[i],1] - 100
           imgpre[smalerX[i],smalerY[i],2] = imgpre[smalerX[i],smalerY[i],2] - 100
           i = i+1    
#    i = 0 
#    while i < len(graterX2):
#           imgpre[graterX2[i],graterY2[i],0] = imgpre[graterX2[i],graterY2[i],0] + 50
#           imgpre[graterX2[i],graterY2[i],1] = imgpre[graterX2[i],graterY2[i],1] + 50
#           imgpre[graterX2[i],graterY2[i],2] = imgpre[graterX2[i],graterY2[i],2] + 50
#           i = i+1 
#    i = 0 
#    while i < len(smalerX2):
#           imgpre[smalerX2[i],smalerY2[i],0] = imgpre[smalerX2[i],smalerY2[i],0] - 50
#           imgpre[smalerX2[i],smalerY2[i],1] = imgpre[smalerX2[i],smalerY2[i],1] - 50
#           imgpre[smalerX2[i],smalerY2[i],2] = imgpre[smalerX2[i],smalerY2[i],2] - 50
#           i = i+1
    
    #Speichert Foto ab
    b = np.uint8(imgpre)
    img = Image.fromarray(b)
    img.save(_thisDir + os.sep + '/FotoOverallKontrast' + ".jpg", "JPEG", quality=100)
    
    return FileNames
    
    
    #errechnet daten für den Plott, möglich mit 2IFC dataframe oder Yes-No dataframe
def evaluationForPlot (givenData):
    
    
    count=[]
    correct_fit = []
    n_total_fit = []
    o = 0
#    print(dataframe_signalintensity.groupby('response').size())
    i=0
#    print("hier")
    list_of_intensitys = givenData['signal_intensity'].value_counts().index.tolist()
    ## sortiere in Aufsteigender reihenfolge
    sortiert = np.sort(list_of_intensitys, axis=None)     # sort the flattened array
    #geht jede Signalstärke durch
    for x in sortiert:
        correct = 0
        wrong = 0
        #subdataframe für signalintensität x
        dataframe_signalintensity = givenData[givenData['signal_intensity'] == x]
        #erstellt liste mit response und anzahl
        answers = dataframe_signalintensity.groupby('response').size()
        answerOptions = dataframe_signalintensity['response'].value_counts().index.tolist()
        
        #speichert die anzahl aus anwers für eine konkrete response ab
        for y in answerOptions:
            
            if y == "Hit" :
                correct = correct + answers['Hit']
            if y == "False Alarm":
                wrong = wrong + answers['False Alarm']
            if y == "Correct Rejection":
                correct = correct + answers['Correct Rejection']
            if y == "Miss":
                wrong = wrong + answers['Miss']
            if y == "No Answer" :
                wrong = wrong + answers['No Answer']
                #####
            if y == "correct answer" :
                correct = correct + answers['correct answer']
            if y == "wrong answer" :
                wrong = wrong + answers['wrong answer']

        
        correct_fit.append(correct)
        n_total_fit.append(correct + wrong)

        count.append(float(correct) / float(correct + wrong))
        i = i+1
        
    data = np.empty([len(sortiert),3], dtype=float)
    sorted_ar = np.array(sortiert)
    correct_psyfit = np.array(correct_fit)
    n_total_psyfit = np.array(n_total_fit)
    
    #Datenvorbereitung für Psysignifit
    for k in sorted_ar:
        
        
        data[o][0] = sorted_ar[o]
        data[o][1] = correct_psyfit[o]
        data[o][2] = n_total_psyfit[o]

        o = o+1
    
    return (data)


####################    
#by the √2 rule d'2AFC = √2 d'Yes/No
def calc2AFCSuggestion (dataPerson):
    list_of_intensitys = dataPerson['signal_intensity'].value_counts().index.tolist()
    
    listHit = []
    listFA = []
    #Array für Anzahl Correct Rejection und False Alarm
    listNCoFa = []
    #Array für Anzahl Hits und Misses
    listNHiMi = []
    listIntensitys = []
    smaltoBig = np.sort(list_of_intensitys, axis=None)
    suggestionData = np.empty([len(list_of_intensitys),3], dtype=float)
    
    #Schleife geht jede Signalintensität durch
    for x in smaltoBig:
        Hits= 0
        FalseAlarm= 0
        other = 0
        NCo = 0
        NMi = 0
        dataframe_signalintensity = dataPerson[dataPerson['signal_intensity'] == x]
        answers = dataframe_signalintensity.groupby('response').size()
        answerOptions = dataframe_signalintensity['response'].value_counts().index.tolist()
        
        #Zählt Hits, False Alarms Correct Rejections und Misses bei einer Signalintensität
        for y in answerOptions:
            
            if y == "Hit" :
                Hits= Hits+ answers['Hit']
            if y == "False Alarm":
                FalseAlarm= FalseAlarm+ answers['False Alarm']
            if y == "Correct Rejection":
                NCo = NCo + answers['Correct Rejection']
            if y == "Miss":
                NMi = NMi + answers['Miss']
            if y == "No Answer" :
                other = other + answers['No Answer']
                ##### for fit 

        #abspeichern der Daten
        listHit.append(Hits)
        listFA.append(FalseAlarm)
        listNCoFa.append(FalseAlarm+ NCo)
        listNHiMi.append(Hits+ NMi)
        listIntensitys.append(x)
        #zur nächsten Signalintensität
        
    a = 0
    #Umwandlung in Arrays
    np.array(listHit)
    np.array(listFA)
    np.array(listNHiMi)
    np.array(listNCoFa)
    np.array(listIntensitys)
    o = 0
    
    ### für jede der 3 Signalstärken soll ein D2IFC berechnet werden 
    for p in listHit:
        #berechnet bedingte Wahrscheinlichkeit für einen Hit
        relHitForIntensity=float(listHit[a]/listNHiMi[a])

        #berechnet bedingte Wahrscheinlichkeit für einen False Alarm
        relFaForIntensity=float(listFA[a]/listNCoFa[a])
        
        #Berechnung d = z(Hit)-z(FA)
        DYesNo = scipy.stats.norm.ppf(relHitForIntensity) - scipy.stats.norm.ppf(relFaForIntensity)
#        print(DYesNo)
        #umrechnung zu D2IFC
        D2IFC = (math.sqrt(2)*DYesNo)
        
        #counter für nächste Signalstärke hoch Zählen 
        a = a+1
#        print(D2IFC)
        
    
        criterium = D2IFC/2
        #berechnung WS(Hit) prognose
        WsHitAFC = scipy.stats.norm.cdf(((D2IFC - criterium)/math.sqrt(2)))


        NegD2IFC = 0-D2IFC   
        #berechnung WS (FA) für 2IFC
        WsFAAFC = scipy.stats.norm.cdf(((NegD2IFC - criterium)/math.sqrt(2)))

        smaltoBig = np.sort(listIntensitys, axis=None)
        
        ## umrechnung von False Alarm zu Correct Rejection (1-FA)
        # ws(CorrectRejection) + ws(Hit)/2 = ws(correct)
        WsCorrect = (WsHitAFC + (1-WsFAAFC))/2
        
        #speichert Signalintensität in Ergebnisarray
        suggestionData[o][0] = smaltoBig[o]
        
        nGes = listNCoFa[o] + listNHiMi[o]
        
        # wie viele von nGes korrekt sein werden
        numberCorrect = WsCorrect*nGes
        
        #Anzahl der Korrekten
        suggestionData[o][1] = numberCorrect
        #Anzahl gesamt 
        suggestionData[o][2] = nGes
#        print (data[o][0])
#        print (data[o][1])
#        print (data[o][2])
        o = o+1
    return suggestionData 
#        
#    ts.plot()
#    plt.plot(sortiert, D)
#    plt.ylim(0, 1)
#    plt.show()


## treffer + false alarm
def deePrimeYesNo (dataPerson):
    ## 
    list_of_intensitys = dataPerson['signal_intensity'].value_counts().index.tolist()
    listHit = []
    listFA = []
    listCR = []
    listMiss = []
    listNGes = []
    for x in list_of_intensitys:
        Hits= 0
        FalseAlarm= 0
        Miss = 0
        CorrectR = 0
        other = 0
        dataframe_signalintensity = dataPerson[dataPerson['signal_intensity'] == x]
        answers = dataframe_signalintensity.groupby('response').size()
        answerOptions = dataframe_signalintensity['response'].value_counts().index.tolist()
#        dataframe_signalintensity.groupby('response').size()
        for y in answerOptions:
            
            if y == "Hit" :
                Hits= Hits+ answers['Hit']
            if y == "False Alarm":
                FalseAlarm= FalseAlarm+ answers['False Alarm']
            if y == "Correct Rejection":
                CorrectR = CorrectR + answers['Correct Rejection']
            if y == "Miss":
                Miss = Miss + answers['Miss']
            if y == "No Answer" :
                other = other + answers['No Answer']
                ##### for fit 

            
        listHit.append(Hits)
        listFA.append(FalseAlarm)
        listCR.append(CorrectR)
        listMiss.append(Miss)
        listNGes.append(Hits+ FalseAlarm+ other)
        
    a = 0
    np.array(listHit)
    np.array(listFA)
    np.array(listCR)
    np.array(listMiss)
    np.array(listNGes)
    
    for p in listHit:
        hitProbability = float(listHit[a])/(listHit[a]+listMiss[a])
        faProbability = float(listFA[a])/(listFA[a]+listCR[a])
        dprime = scipy.stats.norm.ppf(hitProbability) - scipy.stats.norm.ppf(faProbability)
        print ('%s DPRIME %s' % (a+1,dprime))
        a = a+1
    
        
    
def DeePrime2IFC (dataPerson):
    list_of_intensitys = dataPerson['signal_intensity'].value_counts().index.tolist() 
    listHit = []
    listFalseA = []
    listCorrectR = []
    listMiss = []
    smaltoBig = np.sort(list_of_intensitys, axis=None)
    listNGes = []
    # for each signal intensity
    for x in smaltoBig:
        Hit = 0
        FalseA = 0
        CorrectR = 0
        Miss = 0
        other = 0
        # filters only specific signal intensity
        dataframe_signalintensity = dataPerson[dataPerson['signal_intensity'] == x]
        # filters only trials where stimulus was on position 1 (hits & misses)
        dataStimOnOne = dataframe_signalintensity[dataframe_signalintensity['signal_on_stimuluspos1'] == True]
        # filters only trials where stimulus was on position 2 (false as & correct rs)
        dataStimOnTwo = dataframe_signalintensity[dataframe_signalintensity['signal_on_stimuluspos1'] == False]
        # gets the amount of correct and wrong answers with stimulus on position one
        answersOnOne = dataStimOnOne.groupby('response').size()
        # gets the amount of correct and wrong answers with stimulus on position two
        answersOnTwo = dataStimOnTwo.groupby('response').size()
        # correct answer & wrong answer
        answerOptions = dataframe_signalintensity['response'].value_counts().index.tolist()

        for y in answerOptions:
            
            if y == "correct answer" :
                Hit = Hit + answersOnOne['correct answer']
            if y == "wrong answer":
                Miss = Miss + answersOnOne['wrong answer']
            if y == "correct answer" :
                CorrectR = CorrectR + answersOnTwo['correct answer']
            if y == "wrong answer":
                FalseA = FalseA + answersOnTwo['wrong answer']
                
        listHit.append(Hit)
        listFalseA.append(FalseA)
        listCorrectR.append(CorrectR)
        listMiss.append(Miss)
        listNGes.append(Hit + FalseA + CorrectR + Miss + other)
      
    a = 0
    np.array(listHit)
    np.array(listFalseA)
    np.array(listNGes)
    
    #gibt DeePrime aus, beginnend mit dem d' zur kleiner Signalintensität
    for p in listHit:
        hitProbability = float(listHit[a])/(listHit[a]+listMiss[a])
        faProbability = float(listFalseA[a])/(listFalseA[a]+listCorrectR[a])
        dprime = scipy.stats.norm.ppf(hitProbability) - scipy.stats.norm.ppf(faProbability)
        print ('%s DPRIME %s' % (a+1,dprime))
        a = a+1



###################### Execution ######################

### PREPARATION OF DATA###
 
### a list of filenames in Dictionary 
FileNames=createListOfAllCSVFilesInDic() 

# Create a list of all Dataframes in Dicrionary
df_list = [GetFile(fname) for fname in FileNames]

# Combine all of the dataframes into one big Dataframe
big_df = pd.concat(df_list)

# delet whatever is unnecessary 
del big_df['trials.thisTrialN']
del big_df['trials.thisN']
del big_df['trials.thisIndex']

#subdata for Yes no Task 
subData = big_df.loc[big_df['expName'] == "Yes-No Task"]

#subdata for the 2IFC Task
subData2IFC = big_df.loc[big_df['expName'] == "2IFC"]

#kann Datenframe wieder umwandeln in CSV Datei
#big_df.to_csv('BigData.csv', index=False)
#subData.to_csv('DataYesNo.csv', index=False)


#####Picture Filtering
makePictureOverAll(create_subdataset_for_FalseAlarms())


#####
#nameVPN= 'x'

##### 2IFC + Suggestion start

#dataOne = evaluationForPlot (create_subdataset_for_participant (nameVPN))
#dataTwo = calc2AFCSuggestion(create_subdataset_for_participant (nameVPN))
#dataThree = evaluation2IFC (create_subdataset_for_participant2IFC(nameVPN))
#options             = dict() 
#options['expType']     = 'nAFC' 
#options['expN']          = 2 
#resultOne = ps.psignifit(dataOne, options)
#result = dict()
#resultTwo = ps.psignifit(dataTwo, options)
#ps.psigniplot.plotPsych(resultOne)
#ps.psigniplot.plotPsych(resultTwo, dataColor=[0.8,0.9,0],lineColor=[0.8,0.9,0])
#resultThree = ps.psignifit(dataThree, options)
#ps.psigniplot.plotPsych(resultThree, dataColor=[0.2,0.5,0],lineColor=[0.2,0.5,0])
##### 2IFC + Suggestion end



###### create psychometric function for VPN
# prints Threshhold at 65%,75%,85%
#
#dataOne = evaluationAndPlot (create_subdataset_for_participant (nameVpn))
#options             = dict() 
#options['expType']     = 'nAFC'   # choose 2-AFC as the experiment type  
#options['expN']          = 2 
#options2             = dict() 
#options2['expType']     = 'nAFC'   # choose 2-AFC as the experiment type  
#options2['expN']          = 2 
#options3             = dict() 
#options3['expType']     = 'nAFC'   # choose 2-AFC as the experiment type  
#options3['expN']          = 2 
#
#
#options['threshPC']   = 0.3
#options2['threshPC']   = 0.5
#options3['threshPC']   = 0.7
#
#resultOne = ps.psignifit(dataOne, options)
#resultTwo = ps.psignifit(dataOne, options2)
#resultThree = ps.psignifit(dataOne, options3)
#result = dict()
#
##result['conf_Intervals']
#ps.psigniplot.plotPsych(resultOne)
#
#print("Hier den Wert ablesen 0.65%:")
#print(resultOne['Fit'][0])
#print("Hier den Wert ablesen 0.75%:")
#print(resultTwo['Fit'][0])
#print("Hier den Wert ablesen 0.85%:")
#print(resultThree['Fit'][0])

## Create psychometric function end


