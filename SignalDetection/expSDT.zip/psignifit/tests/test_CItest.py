import psignifit as ps

def test_test():
    assert True
